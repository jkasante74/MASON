package ecosystem;

import sim.engine.SimState;										// Needed to import the SimState class which controls the simulation environment
import sim.field.continuous.Continuous2D;
import sim.util.Bag;
//import sim.field.grid.*;										// Needed to import the spaceGrid
import sim.util.Double2D;




public class Model extends SimState   {			// This ensures that we are using the MASON simulating environment
private static final long serialVersionUID = 1L;
	
//	public SparseGrid2D rabbitSpace, grassSpace;				 // This is a 2D space in which bags are created for each cell once an
                                                                // agent or a particle first moves into a cell.  This allows multiple
                                                                // agents or particles to occupy the same cell.
  
	public Continuous2D rabbitSpace;
	public Continuous2D grassSpace;
	public Continuous2D weedsSpace;
	public int gridWidth = 50;
    public int gridHeight = 50;
    public long maxAgents = 50;
    public int rabbitNum = 1;									// Define the number of rabbits
    public int grassNum = 4;
    public int grassGrowthRate = 40;
    public int weedsGrowthRate = 40;
    public boolean avoidCollisions = true; 					   // Particles collide?
    public boolean toroidal = false;  						  // Are there boundaries for rabbits or not? 	
    public boolean movementCost = false;  						  // Are there boundaries for rabbits or not?
    public int mobMod = 0;
    String mobilityMod = "Random Walk";
    public int stepsInterval = 10;
    public int simtime = 0;
    public double energy = 10;
    public double moveCost = 0.01; 
    public double reproduceLevel = 30;
    public int maxRabbitPop = 5;
    public Bag allAgents = new Bag();
   // private int currentRabbits = 0;
    
    public int currentRabbits = 0;
    public String errMsg = null;
    public volatile int grassGrowthCount = 1;
    public double rabbitObserveDistance = 1.5; 
    public boolean popthreshold = false;
    
    /**
     * super uses the constructor method from the parent class
     * @param seed
     */
    public Model(long seed) {					
		super(seed);													
		
	}
    /**Let us inherit from MASON start method and override it
     * 
     */
    public void start(){
    	super.start();	
    	int grassBirth = (grassNum +rabbitNum);
        //rabbitSpace = new SparseGrid2D(gridWidth, gridHeight); //create a 2D space for our agents for SparseGrid.
    	rabbitSpace = new Continuous2D(1.0,gridWidth, gridHeight); //create a 2D space for our agents.
    	rabbitSpace.clear(); //Let's clear the environment of all agents
    	
    	
    	
    	//Locate the agents randomly into the space you have just created
    	for(int i=0;i < rabbitNum+grassNum;i++){
            Rabbits r = new Rabbits(this);
            Grass g = new Grass(this);
            Weeds w = new Weeds(this);
            
          // This is for the moving rabbit agents
            if(i<rabbitNum){
            	//rabbitSpace.setObjectLocation(p, p.x, p.y);   //This is for Sparse2D
            	rabbitSpace.setObjectLocation(r, new Double2D(r.x, r.y));
            	addRabit(r);
            	System.out.println(r+"\t"+ r.x + "\t" + r.y);
            }
            
            //This is for the stationary grass agents
            else{
           // 	 	rabbitSpace.setObjectLocation(g, g.x, g.y);   //This is for Sparse2D
            		rabbitSpace.setObjectLocation(g, new Double2D(g.x, g.y));
            		
                  	System.out.println(g+"\t"+ g.x + "\t" + g.y);
                  	
                  	if((grassBirth - i) == 1){
                  		schedule.scheduleRepeating(g);
                  	    schedule.scheduleRepeating(w);
                  	}
                  	
            }
            r.setavoidCollisions(avoidCollisions);				//Pass the value of collisions to each particle
            r.setboundaries(toroidal);					 	   //Pass the state of whether there is toroidal or not to each particle
           
    	}
    	
    	
    }
    
    /**
     * lets grow some grasses every step
     */
    
    
    /**
     * Add the newly created rabbit to the schedule 
     * @param r
     */
    public void addRabit(Rabbits r) {
    	r.event = schedule.scheduleRepeating(r);
    	currentRabbits++;
    	errMsg = null;
    	if(currentRabbits == maxRabbitPop) {
    		errMsg = "Population threshold reached..";
    		popthreshold = true;
    	}
    	
    }
  
    
    
    /**
     * Return true if the rabbit population been reached?
     * @return 
     */
    public boolean hasSpaceForNewRabbit() {
    	return currentRabbits < maxRabbitPop;
    }
    
    /**
     * Should we reproduce a new grass
     * @return true / false
     */
    public boolean reproduceNewGrass() { 
    	long mysteps = schedule.getSteps();
    	long i = (mysteps  % grassGrowthRate);
    	
    	 if(i==0){
    		 return true;
    	 
    	 }
    	 else
    		 return false;
    	
    				
    }
    
    /**
     * Should we reproduce a new grass
     * @return true / false
     */
    public boolean reproduceNewWeeds() { 
    	long mysteps = schedule.getSteps();
    	long i = (mysteps  % weedsGrowthRate);
    	
    	 if(i==0){
    		 return true;
    	 
    	 }
    	 else
    		 return false;
    	
    				
    }
    
    
    
    /**
     *  Lets develop gets and Sets method 
     *  in the Model to be able to change parameter values whenever we want in the model tab.
     * @return
     */
    
    public int getgridWidth(){
    	return gridWidth;
    }

    public void setgridWidth(int i){
    	if(i>0)
    		gridWidth = i;
    }

    public int getgridHeight(){
    	return gridHeight;
    }

   public void setgridHeight(int i){
        if(i>0)
    		gridHeight = i;
    }

   
   //Develop a set and get method for initial number of rabbits
    public int getRabbitNum(){
       return rabbitNum;
    }

    public void setRabbitNum(int i){
       if(i>0)
          rabbitNum = i;
      }
    
    
  //Set the cost of movement in Rabbits
    public double getrabbitMovementCost(){
    	return moveCost;
    }
    
    public void setrabbitMovementCost(double i){ 
        if(i>0)
           moveCost = i;
       }
    
    
    //Set energy achieved per eating a grass for rabbits
    public double getenergyGained(){
    	return energy;
    }
    
    public void setenergyGained(double i){ 
        if(i>0)
           energy = i;
       }
     
  //Set the energy level at which rabbits reproduce new offspring
    public double getreproduceEnergy(){
    	return reproduceLevel;
    }
    
    public void setreproduceEnergy(double i){ 
        if(i>0)
           reproduceLevel = i;
       }
    
    
  //Set the maximum number of Rabbits allowed in this simulation
    public int getrabbitPopThreshold(){
    	return maxRabbitPop;
    }
    
    public void setrabbitPopThreshold(int i){ 
        if(i>0)
           maxRabbitPop = i;
       }
    
    
    public double getrabbitObserveDistance(){
    	return rabbitObserveDistance;
    }
    
    public void setrabbitObserveDistance(double i){ 
        if(i>0)
        	rabbitObserveDistance = i;
       }
    
    
    
  //Develop a set and get method for grass initial number
    public int getGrassNum(){
        return grassNum;
      }
 
     public void setGrassNum(int i){ 
        if(i>0)
           grassNum = i;
       }
     
     // Develop a set and get method for the grass reproduction rate
     
     public int getgrassReproduceRate(){
         return grassGrowthRate;
      }

      public void setgrassReproduceRate(int i){
         if(i>0)
            grassGrowthRate = i;
        }
     
      
      
   // Develop a set and get method for the weeds reproduction rate
      
      public int getWeedsReproduceRate(){
          return weedsGrowthRate;
       }

       public void setWeedsReproduceRate(int i){
          if(i>0)
             weedsGrowthRate = i;
         }
      
     
     
    //Set and Get for whether to avoid or permit collision to be checked or unchecked in the Model Parameter
   /**
    * This method returns the decision whether agents avoid collisions or not 
    * @return avoidCollisions
    */
     public boolean getavoidCollisions(){
        return avoidCollisions;
      }

     /**
      * This method sets the decision whether agents avoid collisions or not 
      * @param x
      */
     public void setavoidCollisions(boolean x){
         avoidCollisions = x;
       }
    
     /**
      * This method returns the decision to include the movement Cost 
      * @return
      */
     public boolean getincludeMovementCost(){
     	return movementCost;
     }
     
     /**
      * This method sets the state whether rabbits are bounded or not 
      * @param x
      */
     public void setincludeMovementCost(boolean x){
     	movementCost = x;
     }

     /**
      * This method returns the decision whether rabbits are bounded or not 
      * @return
      */
     public boolean getToroidal(){
     	return toroidal;
     }
     
     /**
      * This method sets the state whether rabbits are bounded or not 
      * @param x
      */
     public void setToroidal(boolean x){
     	toroidal = x;
     }
      
      public int getstepsToWaypoint(){
      	return stepsInterval;
      }
    
    public void setstepsToWaypoint(int i){
        if(i>0)
    		stepsInterval = i;
    }
      
     /**
      * This method provides options for what mobility model for rabbits
      * @return
      */
      public int getmobilityModel(){	return mobMod;}
      public void setmobilityModel(int b){ 
      	
    	mobMod = b;
      	switch(b) {
      	case 0: mobilityMod = "Random Walk"; break;
      	case 1: mobilityMod = "Random Waypoint"; break;
      	case 2: mobilityMod = "Random Direction"; break;
      	case 3: mobilityMod = "Modified Random Direction"; break;
      	
      	}
      }
      
      public Object dommobilityModel() 
      { 
      return new String[] { "Random Walk", "Random Waypoint", "Random Direction", "Modified Random Direction"};
      }
      
     
	
}






    

