/**
 * This method simulates the movements of the rabbits. Their movement is patterned in a specific order and they 
 * must choose a random location during collision but once they occupy a grass cell, they feed on the grass and gain energy in that process
 * @author jonathanasante
 *
 */

package ecosystem;



import java.awt.Color;
import java.awt.Graphics2D;

import sim.engine.*;
import sim.portrayal.DrawInfo2D;
import sim.util.Bag;
import sim.util.Double2D;
import sim.util.Int2D;
public class Grass implements Steppable{			//This allows MASON to run all the agents defined in this class

	/**
	 * Let's declare the global variables
	 */
	private static final long serialVersionUID = 1L;
	public int y ;
	public int x ;
	public int xdir;
	public int ydir;
	boolean avoidCollisions = true;
	boolean boundaries = true;
	public volatile int growthCount = 1;
	Grass g;
    public Grass(SimState state){
    	Model se =(Model)state;
    	x = se.random.nextInt(se.gridWidth);
		y = se.random.nextInt(se.gridHeight);
    	xdir = se.random.nextInt(2)-1;
    	ydir = se.random.nextInt(2)-1;
    }
    /**
     * Provide a bounded environment for the Grass
     * @param x
     */
    public void setboundaries(boolean x){
		boundaries = x;
	}

	
	/**
	 * Executes at each step in the schedule
	 * @param state
	 */

	

	@Override
	public void step(SimState state) {
		Model se = (Model)state;
				
		if(se.reproduceNewGrass()){		//How fast should grass be reproduced
			reproduce(se);
			
		}
				
	}
	
	
	
	/**
	 * This method reproduces an agent (Grass) at a specific time step interval
	 * @param se
	 * @return 
	 */
	public void reproduce(Model se){
		Bag b = null;
		Int2D newLoc = null;	
		do {
			newLoc = newLocation(se);	//Randomly choose a location within the environment
			b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newLoc.x, newLoc.y)); //get agent at that location
		} while (b != null); 
		
			Grass g = new Grass(se); // create a new rabbit agent
			se.rabbitSpace.setObjectLocation(g, new Double2D(newLoc.x, newLoc.y));
			System.out.println("Grass is born!!");
			
	}
	

	/**
	* Find a new location for the new agent to be placed
	* @return Int2D
	*/
	public Int2D newLocation(final Model se){
		int x,y;
		final int gridWidth = se.gridWidth;
		final int gridHeight = se.gridHeight;
		x = se.random.nextInt(gridWidth - 1) + 1; 
		y = se.random.nextInt(gridHeight - 1) + 1; 
		return new Int2D(x,y);
	}


	/**
	 * This method sets the color code for the weeds
	 */
    protected Color grassColor = new Color(0,0,0);
    public final void draw(Object object, Graphics2D graphics, DrawInfo2D info)
        {
        double diamx = info.draw.width;
        double diamy = info.draw.height; 
       graphics.setColor(grassColor);
       graphics.fillOval((int)(info.draw.x-diamx/2),(int)(info.draw.y-diamy/2),(int)(diamx),(int)(diamy));
    }
		
				
}



